import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-4ZNXWDSS.js";
import "./chunk-ZIHRWEB2.js";
import "./chunk-B3M2ZSKL.js";
import "./chunk-XPJ6PPQG.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-LTPMASOC.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
